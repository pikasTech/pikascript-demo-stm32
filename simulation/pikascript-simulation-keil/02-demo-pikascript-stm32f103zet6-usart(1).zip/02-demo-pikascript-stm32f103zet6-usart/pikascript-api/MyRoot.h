/* ******************************** */
/* Warning! Don't modify this file! */
/* ******************************** */
#ifndef __MyRoot__H
#define __MyRoot__H
#include <stdio.h>
#include <stdlib.h>
#include "MimiObj.h"

MimiObj *New_MyRoot(Args *args);


#endif
