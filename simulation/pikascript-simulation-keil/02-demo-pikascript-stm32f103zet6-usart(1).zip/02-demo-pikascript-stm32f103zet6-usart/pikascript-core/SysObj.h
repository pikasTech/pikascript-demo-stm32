#ifndef _MimiObj_sys__H
#define _MimiObj_sys__H
#include "MimiObj.h"

MimiObj *New_SysObj(Args *args);
#endif
