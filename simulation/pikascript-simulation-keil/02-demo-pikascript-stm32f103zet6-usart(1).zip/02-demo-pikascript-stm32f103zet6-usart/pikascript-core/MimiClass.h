#ifndef _MimiObj_class__H
#define _MimiObj_class__H
#include "dataMemory.h"
#include "MimiObj.h"

MimiObj *New_MimiObj_class(Args *args);
#endif