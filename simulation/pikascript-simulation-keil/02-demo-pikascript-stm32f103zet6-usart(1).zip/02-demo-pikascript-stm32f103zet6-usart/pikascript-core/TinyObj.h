#ifndef __TYNYOBJ__H
#define __TYNYOBJ__H
#include "MimiObj.h"
MimiObj *New_TinyObj(Args *args);
#endif